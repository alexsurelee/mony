create function requesting_user_id() returns text
    stable
    language sql
as
$$
  select nullif(current_setting('request.jwt.claims', true)::json->>'sub', '')::text;
$$;

alter function requesting_user_id() owner to postgres;

grant execute on function requesting_user_id() to anon;

grant execute on function requesting_user_id() to authenticated;

grant execute on function requesting_user_id() to service_role;

